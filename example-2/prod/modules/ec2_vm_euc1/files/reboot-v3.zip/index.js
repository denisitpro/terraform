const AWS = require('aws-sdk');

exports.handler = async (event) => {
    const message = JSON.parse(event.Records[0].Sns.Message);
    const instanceId = message.Trigger.Dimensions.find(d => d.name === 'InstanceId').value;

    const ec2 = new AWS.EC2();
    const params = {
        InstanceIds: [instanceId]
    };

    try {
        const data = await ec2.rebootInstances(params).promise();
        console.log("Success", data);
        return { message: "Instance reboot initiated successfully!" };
    } catch (err) {
        console.error("Failed to reboot instance", err);
        throw err;
    }
};